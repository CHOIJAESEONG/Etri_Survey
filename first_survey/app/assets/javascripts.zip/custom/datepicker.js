$('#user_birthday').datepicker({
    language: "kr",
    autoclose: true,
	format: "yyyy/mm/dd",
	todayBtn: "linked",
    todayHighlight: true
	
});